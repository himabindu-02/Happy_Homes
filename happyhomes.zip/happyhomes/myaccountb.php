<?php
session_start();  // Start the session

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: buyer.php");  // Redirect to login page if not logged in
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Page</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        header {
            background-color: #9C93B5;
            color: white;
            padding: 1em 0;
            text-align: center;
        }
        body {
            font-family: Arial, sans-serif;
            background: url('assets/imgs/back.jpg');
            background-size: cover;
            background-position: center;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            max-width: 600px;
            margin: 50px auto;
            background-color: transparent;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, .2);
        }

        header {
            text-align: center;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        .profile img {
            display: block;
            margin: 0 auto;
            flex: 1 1 40%;
            max-width: 250px;
            border-radius: 150px;
        }
        
       
    </style>

        
</head>
<body>
    <header>
        <h1>HAPPY HOMES</h1>
        <h2>Make your lifestyle better</h2>
    </header>
    <div class="container">
        <h2>My Account</h2>
        
        <section class="profile">
        <img src="assets/imgs/logo.jpg" alt="logo">
            <h2>PROFILE INFO</h2>
            <p><strong>fullname:</strong> <?php echo $_SESSION['fullname']; ?></p>
            <p><strong>Username:</strong> <?php echo $_SESSION['username']; ?></p>
            <p><strong>Email:</strong> <?php echo $_SESSION['email']; ?></p>
            <p><strong>Phonenumber:</strong> <?php echo $_SESSION['phonenumber']; ?></p>
            <p><strong>password:</strong> <?php echo $_SESSION['password']; ?></p>
            <p><strong>gender:</strong> <?php echo $_SESSION['gender']; ?></p>
        </section>
        
        <section class="settings">
            <!-- Additional settings can go here -->
        </section>
        
       
    </div>
</body>
</html>
